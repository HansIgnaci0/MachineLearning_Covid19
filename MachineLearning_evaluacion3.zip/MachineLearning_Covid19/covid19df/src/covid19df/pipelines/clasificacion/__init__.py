from .pipeline import create_classification_pipeline

# Alias para Kedro
create_pipeline = create_classification_pipeline
