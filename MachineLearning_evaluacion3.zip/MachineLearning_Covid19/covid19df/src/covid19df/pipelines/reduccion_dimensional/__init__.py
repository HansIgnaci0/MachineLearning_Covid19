from .pipeline import create_pipeline

# Alias para Kedro
__all__ = ["create_pipeline"]
